package com.teoh.api.repository;

import com.teoh.api.model.ArticuloDelBlog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArticuloDelBlogRepository extends JpaRepository<ArticuloDelBlog, Integer> {
}
