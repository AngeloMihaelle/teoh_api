package com.teoh.api.teoh_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeohApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
